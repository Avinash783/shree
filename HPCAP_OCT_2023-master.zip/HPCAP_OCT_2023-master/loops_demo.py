
# counter = 1
# while counter < 5:
#     print( "You entered: ", int(input("Hello user please enter a number ")) )
#     counter= counter + 1

# #  range ( start=0 , stop , step=1 )        
# print(range(0,5,1 ), list(range(0,5,1 )))
# print(range(5), list(range(5 )))
# print(range(1,5 ), list(range(1,5 )))
# print(range(1,5,2), list(range(1,5,2 )))
# print(list(range(5,2,-1)))

# for counter in range(1,5,1):
#     print( "You entered: ", int(input("Hello user please enter a number ")) )

# for character in "Hello":
#     print(character, end = "-")

# print("\n")

# for list_element in ["H","e","l","l","o"]:
#     print(list_element, end = '-')    


# num=1 
# while(num<10):
#      print(num, end = " ")
#      num+=1
#      break
     

# num=1 
# while(num<10):
#      print(num, end = " ")
#      num= num + 1
#      continue
#      num= num + 1


# # if i want to print 1-5 but loop for 1-9
# num=1 
# while(num<10):
#      if num<6 : 
#         print(num, end = " ")
#      num+=1



# num=1 
# while(num<10):
#      if num<6 : 
#         print("running", num)
#         continue
#      num+=1
#      print(num, end = " ")

# ***********************************************************
# Practice problem 1 
# ***********************************************************
# Create a game for FIZZ BUZZ and keeping playing
# with the user untill the user chooses to skip the game

def my_fizz_buzz():
   input_num = int(input("Enter number:"))
   flag = None    
   if input_num%3 ==0 :
         print("Fizz", end= " ")
         flag = 'Y'
   if input_num%5 ==0:
      print("Buzz")
      flag = 'Y'    
   if flag is None:
      print("Invalid Input")

# skip_char = "*"
# while skip_char != '~':
#    my_fizz_buzz()
#    skip_char= input("\nPlease press ~ to skip ")
   

while True:
   my_fizz_buzz()
   skip_char= input("\nPlease press ~ to skip ")
   if skip_char == '~':
      break


