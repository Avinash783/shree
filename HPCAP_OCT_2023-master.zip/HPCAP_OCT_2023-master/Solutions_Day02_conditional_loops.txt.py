"""
Addition/Squaring/exponenation should be done as part of single function named 
"my_calculator"
which takes in type of operation, number1,number2 as input 
and outputs the answer based on the operation
We need to keep executing my_calculator function 
untill user choose to skip the application
"""

# from function_definitions import *
# def my_calculator():
#     print("****************** MENU ************************")
#     print("1: Addition")
#     print("2: Square")
#     print("3: Exponentation ")
#     choice = int(input ("Please select your choice"))

#     if choice == 1 :
#         first_num = int(input("Please enter First number:"))
#         second_num = int(input("Please enter Second number:"))
#         returned_value = my_addition(first_num,second_num)
#         print("The Addition of the numbers is ",returned_value)

#     elif choice == 2 :
#         first_num = int(input("Please enter First number:"))
#         returned_value = my_square(first_num)
#         print("The Square of the number is ",returned_value)
#     elif choice == 3 :
#         first_num = int(input("Please enter First number:"))
#         second_num = int(input("Please enter Second number:"))
#         returned_value = my_exponenation(first_num,second_num)
#         print("The exponenation of the numbers is ",returned_value)

# def iterative_calculator():
#     while(True):
#         print("Lets start   !!!! ")
#         my_calculator()	
#         choice = input("\n Do you want to continue (Y/N)").lower()     
#         if choice == 'n':
#             break

# iterative_calculator()     

# """1) Take a number from the user and print sum from 1 to that number """

# sum_upto_number = int(input("Please enter a number to sum upto"))

# cnt = 1 
# my_sum= 0  
# while(cnt <=sum_upto_number ):
#     my_sum = my_sum+cnt
#     cnt+=1
# print("The sum upto" ,sum_upto_number, "is",my_sum);

# # or 
# sum = 0 
# for i in range(1,int(input("Please enter a number"))+1):
#     sum = sum+i
# print(sum)   

# """2) Take a number from the user and print all Odd numbers from 1 to that number """

# number_from_user = int(input("Please enter a number "))

# current_number_being_checked = 1
# while(current_number_being_checked<= number_from_user):
#     if current_number_being_checked%2 !=0:
#         print(current_number_being_checked,end=" ")
#     current_number_being_checked+=1

# # using for loop
# for i in range(1,number_from_user+1,2):
#     print(i , end = "--")

# """3) Take a number from the user and print all Even numbers from 1 to that number """

# number_from_user = int(input("Please enter a number "))

# current_number_being_checked = 0
# while(current_number_being_checked<= number_from_user):
#     if current_number_being_checked%2 ==0:
#         print(current_number_being_checked,end=" ")
#     current_number_being_checked+=1

# # using for loop
# for i in range(0,number_from_user+1,2):
#     print(i , end = "--")
