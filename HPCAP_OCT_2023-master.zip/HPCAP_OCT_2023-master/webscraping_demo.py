"""
Requests is a popular Python library that is used for making HTTP requests to various endpoints. It is an alternative to Python's built-in urllib module and provides a simpler and more user-friendly interface.

With requests, you can perform various types of HTTP requests such as GET, POST, PUT, DELETE, and more. It also supports sending data in various formats such as form data, JSON, and XML.

# example of how to use the requests library to send a GET request to a website
"""

# import requests
# headers = {
#     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'
# }

# params = {
#     'q': 'python'
# }

# response = requests.get('https://www.google.com/search', headers=headers, params=params)
# print(response.status_code)
# print(response.content)
"""
------------
web scraping
-------------

Web scraping is the process of extracting data from websites using software programs called web scrapers or crawlers. The term "scraping" refers to the act of pulling data from a website, while "web" indicates that the data is being taken from the internet.

Web scraping can be done manually, but it is often automated using specialized software tools. Web scrapers use various techniques to extract data from websites, including parsing HTML code, using APIs, and interacting with web forms.

--
common applications of web scraping:
--

Price comparison and monitoring: Many businesses use web scraping to collect pricing information of their competitors and adjust their prices accordingly to stay competitive.

Market research: Web scraping can be used to gather information about customers, their interests, and the market trends. This information can help businesses in developing targeted marketing strategies.

Lead generation: Web scraping can be used to collect contact information of potential customers from various sources like social media, forums, and directories.

Content aggregation: Web scraping can be used to gather content from various websites to create an aggregate source of information on a specific topic.

Job search: Web scraping can be used to scrape job postings from various websites and provide aggregated job listings for job seekers.

Sentiment analysis: Web scraping can be used to gather customer feedback and reviews from various websites, which can be analyzed to understand the sentiment towards a product or service.

Academic research: Researchers can use web scraping to collect data for research purposes, such as analyzing social media activity or monitoring news trends

--
Brief overview of some techniques to extract data from websites:
--

1) Parsing HTML code: This is the most common technique used in web scraping, and involves using libraries such as BeautifulSoup or Scrapy to parse the HTML code of a webpage and extract the desired information. This technique works well for websites with static HTML code that does not change frequently.

2) Using APIs: Many websites provide APIs (Application Programming Interfaces) that allow users to access their data in a structured format. APIs can be used to extract data from websites in a programmatic way, without the need to parse HTML code.

3) Interacting with web forms: Some websites require users to fill out web forms to access data or perform certain actions. Web scraping tools can be used to automate the process of filling out web forms and extracting the desired information.

4) Screen scraping: This technique involves automatically navigating through a website and capturing data from the screen using image recognition or OCR (Optical Character Recognition) technology. Screen scraping can be useful for websites that do not provide APIs or have complex JavaScript-based interfaces.

5) Web crawling: This technique involves automatically navigating through a website and extracting data from multiple pages. Web crawlers can be used to extract large amounts of data from websites, but care must be taken to avoid overloading the website's servers and violating the website's terms of service.


LFJL1HUVKTE2DWT3
# # """
# # a web scraping example 1
# import requests
# from bs4 import BeautifulSoup

# # The URL of the BBC News homepage
# url = 'https://www.bbc.com/news'

# # Make a GET request to the URL
# response = requests.get(url)

# # Create a Beautiful Soup object from the response content
# soup = BeautifulSoup(response.content, 'html.parser')
# # Find all the headline tags on the page
# headlines = soup.find_all('h3')

# # Loop through the headline tags and print the text
# for headline in headlines:
#     print(headline.text)


"""
-----------------------------------------------------------------------------
Attributes and methods of a response object in Python's requests library:
-----------------------------------------------------------------------------
Attributes:

response.status_code: The HTTP status code of the response (e.g. 200 for a successful response, 404 for a "Not Found" error, etc.)
response.headers: A dictionary of the HTTP headers sent by the server in the response
response.text: The content of the response, as a string (if the response is text-based)
response.content: The content of the response, as bytes (if the response is binary)
response.url: The URL of the final page after any redirects (if they occurred)
response.request: The PreparedRequest object that was used to create the request, including the HTTP method, URL, headers, and body
response.cookies: A dictionary of any cookies returned by the server in the response
response.history: A list of any previous responses that led to the final response (if there were any redirects)

Methods:

response.raise_for_status(): Raises an exception if the status code of the response indicates an error (i.e. not in the 200-299 range)
response.json(): Parses the response content as JSON (assuming it is valid JSON)
response.iter_content(): Iterates over the response content in chunks (useful for large files)
response.iter_lines(): Iterates over the response content line by line (useful for text-based responses)
response.close(): Closes the connection to the server (useful when working with large responses to free up system resources)

# """

# example code that demonstrates various methods of a response object and webscraping
import requests
from bs4 import BeautifulSoup

# Send a GET request to the website
url = "http://quotes.toscrape.com/"
response = requests.get(url)

# Print the response status code
print("Response status code:", response.status_code)

# Print the response headers
print("Response headers:", response.headers)

# Print the response content
print("Response content:", response.content)

# Parse the HTML content using BeautifulSoup
soup = BeautifulSoup(response.content, 'html.parser')

# Extract the quotes and authors
quotes = soup.select('span.text')
authors = soup.select('small')

# print(quotes.__len__())
# print(authors.__len__())
# Print the quotes and authors
for i in range(len(quotes)):
    print("Quote:", quotes[i].text)
    print("Author:", authors[i].text)
    print()


