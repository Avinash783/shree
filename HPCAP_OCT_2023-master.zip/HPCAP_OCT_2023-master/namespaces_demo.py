import builtins
# # test = 123


# def f2():
#     # test = 89
    
#     def f22():
#         # test = 8899
#         print("Inside f22",test)
#     f22()
    
# f2()        


# test = 123
# def f2():
#     test = 89
    
#     def f22():
#         # nonlocal test
#         global test
#         test = 8899
#         print("Inside f22",test)
#     f22()
#     print("Inside f2",test)

# print("Before change : At module level ",test)    
# f2()  
# print("After change : At module level ",test)


print(" BEFORE builtins scope address of print function: ", id(print))
def print():
    pass

print("AFTER builtins scope address of print function: ", id(print))

