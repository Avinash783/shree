## 1: write a program to take some text lines from the user and write it to the file

# file_handle = open("my_file.txt","w")
# while(True):
#     line_provided = input("Please enter a line :")
#     file_handle.write(line_provided)
#     file_handle.write("\n")
#     choice = input("Do you want to continue (Y/N)").lower()
#     if choice == 'n':
#         break
# file_handle.close()

## 2: write a program to read from a file and write to another file 

# input_file_handle = open("my_file.txt","r")
# output_file_handle = open("my_file_copy.txt","w")

# for input_line in input_file_handle:
#     output_file_handle.write(input_line)

# # output_file_handle.write(input_file_handle.read())
# input_file_handle.close()    
# output_file_handle.close()  
  
## 3: Write a program to read from a file and modify its content 
## by pre-pending each line with "HPCAP" 

input_file_handle = open("my_file.txt","r")
contents_in_list = []

for input_line in input_file_handle:
    contents_in_list.append(input_line)
input_file_handle.close()

input_file_handle = open("my_file.txt","w")    
for list_input_line in contents_in_list:
        input_file_handle.write("HPCAP "+list_input_line)

## 4: Write a program to read from a file, pre-pending each line with "HPCAP" 
## and write to the different file 

# input_file_handle = open("my_file.txt","r")
# output_file_handle = open("my_modified_file.txt","w")

# for input_line in input_file_handle:
#     modified_input_line = "HPCAP "+input_line
#     output_file_handle.write(modified_input_line)

# # output_file_handle.write(input_file_handle.read())
# input_file_handle.close()    
# output_file_handle.close()  

