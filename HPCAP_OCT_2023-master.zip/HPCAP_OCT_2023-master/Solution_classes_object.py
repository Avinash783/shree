"""class Employee:
  
  def __init__(self,rcv_emp_id,rcv_emp_salary,rcv_mgr_id) -> None:
    # instance variables 
    self.emp_id = rcv_emp_id
    self.emp_salary= rcv_emp_salary
    self.mgr_id = rcv_mgr_id
   
  # class variable 
  department_name = "Default"
  
  # instance methods
  def get_emp_salary(self):
      return self.emp_salary
  
  def set_emp_salary(self,rcv_salary):
   self.emp_salary = rcv_salary

  # class method 
  @classmethod
  def get_department_name(cls) :
    return cls.department_name
  
  # static method
  @staticmethod
  def field_expertise():
      print("just displays some expertise for all my employees")
  
def main():
    # 1) create an object employee(100,1000,1)  
    employee_1 = Employee(100,1000,1)
    # 2) do the following for the created object
    #  direct access using .notation
    print("employee_1.empid:",employee_1.emp_id)
    print("employee_1.get_emp_salary():",employee_1.get_emp_salary())
    print("employee_1.mgr_id:",employee_1.mgr_id)
    
    # 3) print the department name 
    print(Employee.get_department_name())
    
    # 4) display the expertise for the employees 
    Employee.field_expertise()
    # 5) Deleting Attributes and Objects
    
    del employee_1.emp_id
    try:
        print(employee_1.emp_id)
    except Exception:
        print("We did not find empid in employee1 object post deletion")    

    del employee_1
    try:
        print(employee_1)
    except Exception:
        print("We did not find employee1 object post deletion")    

main()        

"""

class My_airline :
    
    @classmethod
    def refresh_data(cls):
        cls.airline_name = 'Gaurav Airline'
        cls.cities = {'Delhi','Pune','Mumbai','Bangalore','Chennai','Hyderabad','Patna','Trivandrum'}
        cls.rows = set(range(1,21))
        cls.section = {'A','B','C','D','E','F'}
        cls.flight_numbers = set(range(564262,564362))
    
    def __init__(self,rcv_dep = None , rcv_arr= None) -> None:
        My_airline.refresh_data()
        self.flight_number = My_airline.flight_numbers.pop()  
        self.seat_number = str(My_airline.rows.pop()) + My_airline.section.pop() 
        
        if rcv_dep is None:
            self.departure = My_airline.cities.pop()  
        else:
            self.departure = rcv_dep
        if rcv_arr is None:
            self.arrival = My_airline.cities.pop() 
        else:
            self.arrival = rcv_arr
        

    def display_details(self):
        print(f"""Your ticket details :
--------------------------------------               
Airline_name : {My_airline.airline_name}
Flight_number : {self.flight_number}
Departure: {self.departure}
Arrival: {self.arrival}
Seat_number: {self.seat_number}
              
              """)   


def main():
   ticket_number1 = My_airline('LONDON','USA') 
   ticket_number2 = My_airline()
   
   ticket_number1.display_details()
   ticket_number2.display_details()

main()